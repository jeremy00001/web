"""ola URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import *
from ola.functions import *
from django.contrib import admin
from django.views.generic.base import RedirectView
from django.contrib.auth import views as auth_views

admin.autodiscover()

urlpatterns = [
        url(r'^$', auth_views.login, name='login'),
        url(r'^login/$', auth_views.login, name='login'),
        url(r'^logout/$', auth_views.logout, name='logout'),
        url('^change_password/', change_password),
        url('^favicon.ico$', RedirectView.as_view(url='/static/favicon.ico')),
        url(r'^ola/(\d{1,10})/$', openola),
        url(r'^main/ola/drafted/$', draftedola),
        url(r'^main/ola/approved/$', approvedola),
        url(r'^main/ola/cancelled/$', cancelledola),
        url(r'^main/ola/pending/$', pendingola),
        url(r'^main/ola/overdue/$', overdueola),
        url(r'^main/ola/deadola/$', deadola),
        url(r'^main/ola/rejected/$', rejectedola),
        url('^changeola/new/', newola),
        url('^main/$', display_ola),
        url('^admin/', include(admin.site.urls)),

]