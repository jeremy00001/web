# -*- coding: utf-8 -*-

from django.http import *
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.shortcuts import render, redirect
from fmola.models import team, ola, actionhistory, people
from django.db.models import Q
from django.views.decorators import csrf
from django.core.exceptions import ValidationError
from django.db.utils import DatabaseError


def get_user_view(request):
    current_user = request.user.username
    usr_app_list = list(people.objects.filter(bank_id=current_user).values_list('appname', flat=True))
    return ola.objects.filter(Q(source_appname__in=usr_app_list) | Q(target_appname__in=usr_app_list)).order_by(
        '-last_modified')


def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            # messages.success(request, 'Your password was successfully updated!')
            return redirect('login')
        # else:
        # messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'registration/change_password.html', {
        'form': form
    })


def display_ola(request):
    current_user = request.user.username
    try:
        current_user = int(current_user)
    except ValueError:
        return render(request, 'registration/logged_out.html',
                      {'errorinfo': str(current_user) + " is not a valid user[bankid required]!"})

    if request.user.is_authenticated():
        ob = get_user_view(request)
        d_c = ob.filter(ola_status='Drafted').count()
        a_c = ob.filter(ola_status='Approved').count()
        r_c = ob.filter(ola_status='Rejected').count()
        p_c = ob.filter(ola_status='Pending').count()
        c_c = ob.filter(ola_status='Cancelled').count()
        o_c = ob.filter(ola_status='OverDue').count()
        dead_c = ob.filter(ola_status='DEAD').count()
        showall = 1
        has_manageractions = 0
        people_name_list = people.objects.filter(bank_id=current_user).values_list('name', flat=True)
        people_name = people_name_list[0]
        if people.objects.filter(bank_id=current_user).filter(approver=1).exists():
            has_manageractions = 1
        return render(request, 'main.html', {'has_manageractions': has_manageractions,
                                             'people_name': people_name,
                                             'posts': ob,
                                             'd_c': d_c,
                                             'a_c': a_c,
                                             'r_c': r_c,
                                             'p_c': p_c,
                                             'c_c': c_c,
                                             'o_c': o_c,
                                             'dead_c': dead_c,
                                             'showall': showall,
                                             'username': current_user})
    else:
        return redirect('logout')


def draftedola(request):
    ob = get_user_view(request).filter(ola_status='Drafted')
    return render(request, 'main.html',
                  {'posts': ob, 'showall': 0, 'username': request.user.username})


def approvedola(request):
    ob = get_user_view(request).filter(ola_status='Approved')
    return render(request, 'main.html',
                  {'posts': ob, 'showall': 0, 'username': request.user.username})


def cancelledola(request):
    ob = get_user_view(request).filter(ola_status='Cancelled')
    return render(request, 'main.html',
                  {'posts': ob, 'showall': 0, 'username': request.user.username})


def rejectedola(request):
    ob = get_user_view(request).filter(ola_status='Rejected')
    return render(request, 'main.html',
                  {'posts': ob, 'showall': 0, 'username': request.user.username})


def pendingola(request):
    ob = get_user_view(request).filter(ola_status='Pending')
    return render(request, 'main.html',
                  {'posts': ob, 'showall': 0, 'username': request.user.username})


def overdueola(request):
    ob = get_user_view(request).filter(ola_status='OverDue')
    return render(request, 'main.html',
                  {'posts': ob, 'showall': 0, 'username': request.user.username})


def deadola(request):
    ob = get_user_view(request).filter(ola_status='DEAD')
    return render(request, 'main.html',
                  {'posts': ob, 'showall': 0, 'username': request.user.username})


def what_is_the_next_action(current_status, is_submiter, is_approver):
    nextactionlist = ['']
    if current_status == "Drafted":
        nextactionlist = ['Save', 'Submit', 'New', 'MarkAsTerminated']
    elif current_status == "Pending":
        if is_approver == 1 and is_submiter == 0:
            nextactionlist = ['Approve', 'Reject']
        elif is_approver == 0 and is_submiter == 1:
            nextactionlist = ['Cancel']
        elif is_approver == 1 and is_submiter == 1:
            nextactionlist = ['Approve', 'Reject', 'Cancel']
    elif current_status == "Approved":
        nextactionlist = ['New', 'Cancel', 'MarkAsTerminated']
    elif current_status == "Rejected":
        nextactionlist = ['New', 'Cancel', 'MarkAsTerminated']
    elif current_status == "DEAD":
        nextactionlist = ['New']
    elif current_status == "Cancelled":
        nextactionlist = ['New']
        if is_submiter == 1:
            nextactionlist = ['New', 'MarkAsTerminated']
    elif current_status == "OverDue":
        nextactionlist = ['New', 'MarkAsTerminated']
    return nextactionlist


def openola(request, oid):
    try:
        oid = int(oid)
    except ValueError:
        raise Http404()

    ob = get_user_view(request).filter(id=oid)  # get related ola
    if ob.exists() == 1:  # check if has any related ola
        ob = get_user_view(request).get(id=oid)  # get ola dict
        current_user = request.user.username
        list_source = list_target = team.objects.values_list('appname', flat=True)
        manager_list = team.objects.filter(appname__in=[ob.source_appname, ob.target_appname]).values_list(
            'manager_bankid', flat=True)
        actions = actionhistory.objects.filter(oid=oid).order_by('-id')
        actionlist = ['']

        if not (request.user.username in manager_list):  # check if current user is a manger
            actionlist = ['']
        else:
            if ob.ola_status == "Drafted":
                actionlist = ['Save', 'Submit']
            else:
                is_submiter = 0
                is_approver = 0
                if actionhistory.objects.filter(action='Submit', oid=oid).order_by('-id'):
                    submiter_application = actionhistory.objects.filter(action='Submit', oid=oid).order_by('-id')[
                        0].app_name
                else:
                    submiter_application = ['']
                current_user_managing_applist = team.objects.filter(manager_bankid=request.user.username).values_list(
                    'appname',
                    flat=True)
                if submiter_application == ob.source_appname:
                    other_application = ob.target_appname
                else:
                    other_application = ob.source_appname
                if ob.ola_status == "Pending":
                    if (submiter_application in current_user_managing_applist) and (
                            other_application not in current_user_managing_applist):
                        is_submiter = 1
                        is_approver = 0
                    elif (submiter_application in current_user_managing_applist) and (
                            other_application in current_user_managing_applist):
                        is_submiter = 1
                        is_approver = 1
                    elif (submiter_application not in current_user_managing_applist) and (
                            other_application in current_user_managing_applist):
                        is_submiter = 0
                        is_approver = 1
                    actionlist = what_is_the_next_action(ob.ola_status, is_submiter, is_approver)
                elif ob.ola_status == "Approved":
                    if submiter_application in current_user_managing_applist:
                        is_submiter = 1
                    elif other_application in current_user_managing_applist:
                        is_approver = 1
                    actionlist = what_is_the_next_action(ob.ola_status, is_submiter, is_approver)
                elif ob.ola_status == "Rejected":
                    if submiter_application in current_user_managing_applist:
                        is_submiter = 1
                    elif other_application in current_user_managing_applist:
                        is_approver = 1
                    actionlist = what_is_the_next_action(ob.ola_status, is_submiter, is_approver)
                elif ob.ola_status == "DEAD":
                    actionlist = ['New']
                elif ob.ola_status == "Cancelled":
                    actionlist = ['New']
                elif ob.ola_status == "OverDue":
                    actionlist = ['New']
        # print request.user.username + " is_submiter" + str(is_submiter)
        # print request.user.username + " is_approver" + str(is_approver)
        return render(request, 'changeola.html',
                      {'actions': actions,
                       'source_appname': list_source,
                       'target_appname': list_target,
                       'actionlist': actionlist,
                       'action_type': "Update",
                       'id': ob.id,
                       'ola_status': ob.ola_status,
                       'last_modified': ob.last_modified,
                       'source_appname_origin': ob.source_appname,
                       'target_appname_origin': ob.target_appname,
                       'ola_time': ob.ola_time,
                       'ola_dayshift': ob.ola_dayshift,
                       'file_name': ob.file_name,
                       'comment1': ob.comment, })
    else:
        return render(request, 'registration/logged_out.html',
                      {'errorinfo': "You are not authorised to view OLA-" + str(oid)})


def newola(request):
    list_source = list_target = team.objects.values_list('appname', flat=True)
    actionlist = ['Save', 'Submit']
    if request.method == 'GET':
        # Approve = Reject = Cancel = MarkasDead = CopyToNew = Submit = Save = ""
        return render(request, 'changeola.html',
                      {'actionlist': actionlist,
                       'action_type': "Create",
                       'id': "0",
                       'ola_status': "Drafted",
                       'last_modified': "",
                       'ola_time': "",
                       'ola_dayshift': "0",
                       'file_name': "",
                       'comment': "",
                       'source_appname': list_source,
                       'target_appname': list_target,
                       })

    elif request.method == 'POST':
        save_stats = 0
        insertion_template = {}
        next_action = request.POST['action_taken']
        manage_list = people.objects.filter(approver=1).filter(bank_id=request.user.username).values_list('appname',
                                                                                                          flat=True)
        if (request.POST['source_appname'] in manage_list) or (request.POST['target_appname'] in manage_list):
            if next_action in ['New', 'Save']:
                if next_action == 'Save' and request.POST['olaid'] != "0":
                    insertion_template_ola = ola(id=request.POST['olaid'],
                                                 ola_status=request.POST['olastatus'],
                                                 source_appname=request.POST['source_appname'],
                                                 target_appname=request.POST['target_appname'],
                                                 ola_time=request.POST['ola_time'],
                                                 ola_dayshift=request.POST['ola_dayshift'],
                                                 file_name=request.POST['file_name'],
                                                 comment=request.POST['comment1'], )
                else:
                    insertion_template_ola = ola(ola_status='Drafted',
                                                 source_appname=request.POST['source_appname'],
                                                 target_appname=request.POST['target_appname'],
                                                 ola_time=request.POST['ola_time'],
                                                 ola_dayshift=request.POST['ola_dayshift'],
                                                 file_name=request.POST['file_name'],
                                                 comment=request.POST['comment1'], )

            elif next_action in ['Submit']:
                if request.POST['olaid'] != "0":
                    insertion_template_ola = ola(id=request.POST['olaid'],
                                                 ola_status="Pending",
                                                 source_appname=request.POST['source_appname'],
                                                 target_appname=request.POST['target_appname'],
                                                 ola_time=request.POST['ola_time'],
                                                 ola_dayshift=request.POST['ola_dayshift'],
                                                 file_name=request.POST['file_name'],
                                                 comment=request.POST['comment1'], )
                else:
                    insertion_template_ola = ola(
                        ola_status="Pending",
                        source_appname=request.POST['source_appname'],
                        target_appname=request.POST['target_appname'],
                        ola_time=request.POST['ola_time'],
                        ola_dayshift=request.POST['ola_dayshift'],
                        file_name=request.POST['file_name'],
                        comment=request.POST['comment1'], )
            elif next_action in ['Approve']:
                insertion_template_ola = ola(id=request.POST['olaid'],
                                             ola_status="Approved",
                                             source_appname=request.POST['source_appname'],
                                             target_appname=request.POST['target_appname'],
                                             ola_time=request.POST['ola_time'],
                                             ola_dayshift=request.POST['ola_dayshift'],
                                             file_name=request.POST['file_name'],
                                             comment=request.POST['comment1'], )
            elif next_action in ['Reject']:
                insertion_template_ola = ola(id=request.POST['olaid'],
                                             ola_status="Rejected",
                                             source_appname=request.POST['source_appname'],
                                             target_appname=request.POST['target_appname'],
                                             ola_time=request.POST['ola_time'],
                                             ola_dayshift=request.POST['ola_dayshift'],
                                             file_name=request.POST['file_name'],
                                             comment=request.POST['comment1'], )
            elif next_action in ['Cancel']:
                insertion_template_ola = ola(id=request.POST['olaid'],
                                             ola_status="Cancelled",
                                             source_appname=request.POST['source_appname'],
                                             target_appname=request.POST['target_appname'],
                                             ola_time=request.POST['ola_time'],
                                             ola_dayshift=request.POST['ola_dayshift'],
                                             file_name=request.POST['file_name'],
                                             comment=request.POST['comment1'], )
            elif next_action in ['MarkAsTerminated']:
                insertion_template_ola = ola(id=request.POST['olaid'],
                                             ola_status="DEAD",
                                             source_appname=request.POST['source_appname'],
                                             target_appname=request.POST['target_appname'],
                                             ola_time=request.POST['ola_time'],
                                             ola_dayshift=request.POST['ola_dayshift'],
                                             file_name=request.POST['file_name'],
                                             comment=request.POST['comment1'], )

            if request.POST['olaid'] != "0":
                if request.POST['olastatus'] == ola.objects.get(id=request.POST['olaid']).ola_status:
                    try:
                        insertion_template_ola.save()
                        current_id = insertion_template_ola.id
                        requester_app=""
                        if request.POST['target_appname'] in manage_list:
                            requester_app = request.POST['target_appname']
                        if request.POST['source_appname'] in manage_list:
                            requester_app = request.POST['source_appname']
                        insertion_template_actionhistory = actionhistory(oid=current_id,
                                                                         action=next_action,
                                                                         user_name=request.user.username,
                                                                         app_name=requester_app,
                                                                         previous_status=request.POST['olastatus'],
                                                                         comment=request.POST['comment1'], )
                        insertion_template_actionhistory.save()
                    except DatabaseError as e:
                        raise ValidationError(e)
                        # update the action list here
                    if next_action in ['']:
                        return render(request, "changeola.html", {
                        })
                    else:
                        return HttpResponseRedirect('/ola/' + str(current_id) + '/')
                else:
                    warning_message = "Conflict Detected: OLA " + str(
                        request.POST['olaid']) + " status was changed to " + ola.objects.get(
                        id=request.POST['olaid']).ola_status
                    return render(request, "changeola.html", {
                        'Warning_Message': warning_message,
                    })
            else: #create new ola
                try:
                    insertion_template_ola.save()
                    current_id = insertion_template_ola.id
                    requester_app = ""
                    if request.POST['target_appname'] in manage_list:
                        requester_app = request.POST['target_appname']
                    if request.POST['source_appname'] in manage_list:
                        requester_app = request.POST['source_appname']
                    insertion_template_actionhistory = actionhistory(oid=current_id,
                                                                     action=next_action,
                                                                     user_name=request.user.username,
                                                                     app_name=requester_app,
                                                                     previous_status=request.POST['olastatus'],
                                                                     comment=request.POST['comment1'], )
                    insertion_template_actionhistory.save()
                except DatabaseError as e:
                    raise ValidationError(e)
                if next_action in ['']:
                    return render(request, "changeola.html", {
                    })
                else:
                    return HttpResponseRedirect('/ola/' + str(current_id) + '/')
        else:
            warning_message = "You can only submit OLA related to following application(s):"
            for i in manage_list:
                warning_message = warning_message + i + ";"
            return render(request, "changeola.html", {
                'actionlist': actionlist,
                'action_type': "Create",
                'id': "0",
                'ola_status': "Drafted",
                'last_modified': "",
                'ola_time': "",
                'ola_dayshift': "0",
                'file_name': "",
                'comment1': "",
                'source_appname': list_source,
                'target_appname': list_target,
                'Warning_Message': warning_message,
            })
