# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import *

# Register your models here.


class olaAdmin(admin.ModelAdmin):
    list_display = ['ola_status','last_modified','source_appname','target_appname',	'ola_time','ola_dayshift','file_name','comment']
    list_filter = ['ola_status','source_appname','target_appname']
    search_fields = ['source_appname','ola_status']
    #list_per_page =

class peopleAdmin(admin.ModelAdmin):
    list_display = ['name','approver','email','bank_id','appname','last_modified']
    list_filter = ['appname']
    search_fields = ['name']
    #list_per_page =

class teamAdmin(admin.ModelAdmin):
    list_display = ['name','manager_bankid','team_email','appname','last_modified']
    list_filter = ['name','appname']
    search_fields = ['name']
    #list_per_page =

class AuditAdmin(admin.ModelAdmin):
    list_display = ['action','previous_status','user_name','app_name','comment','last_modified']
    list_filter = ['app_name','action']
    search_fields = ['app_name','action']
    #list_per_page =


admin.site.register(ola,olaAdmin)
admin.site.register(people,peopleAdmin)
admin.site.register(team,teamAdmin)
admin.site.register(actionhistory,AuditAdmin)