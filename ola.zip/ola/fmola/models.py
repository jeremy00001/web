# models.py
from django.db import models


class team(models.Model):
    name = models.CharField(max_length=300, blank=False)
    manager_bankid = models.CharField(max_length=300, blank=False)
    team_email = models.EmailField(blank=False)
    appname = models.CharField(max_length=300, blank=False)
    last_modified = models.DateTimeField(auto_now=True)
    def __unicode__(self):
        return self.name


class ola(models.Model):
    ola_status = models.CharField(max_length=20,blank=False,default='Draft')
    last_modified = models.DateTimeField(auto_now=True)
    source_appname = models.CharField(max_length=200, blank=False)
    target_appname = models.CharField(max_length=200, blank=False)
    ola_time = models.TimeField(null=True,blank=False)
    ola_dayshift = models.IntegerField(default=0,blank=False)
    file_name = models.CharField(max_length=500, blank=False)
    comment = models.TextField()


class people(models.Model):
    name = models.CharField(max_length=300, blank=False)
    approver = models.BooleanField(default=False)
    email = models.EmailField(blank=False)
    bank_id = models.IntegerField(blank=False)
    appname = models.CharField(max_length=200, blank=False)
    last_modified = models.DateTimeField(auto_now=True)
    def __unicode__(self):
        return self.name

class actionhistory(models.Model):
    oid = models.IntegerField(blank=False) #olaid
    action = models.CharField(max_length=300, blank=False)
    user_name = models.IntegerField(blank=False)
    app_name = models.CharField(max_length=300, blank=False)
    previous_status = models.CharField(max_length=300, blank=False)
    comment = models.TextField()
    last_modified = models.DateTimeField(auto_now=True)








